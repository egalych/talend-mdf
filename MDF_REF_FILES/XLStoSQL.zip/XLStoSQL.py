import argparse
import pandas as pd

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("filename", help="Input filename")
    parser.add_argument("--tabs","-t", nargs='*', help="Specific tabs")
    args = parser.parse_args()
    print("\nProcessing "+args.filename+"...\n\n")
    xl = pd.ExcelFile(args.filename)
    if args.tabs is not None:
        list_of_tabs = args.tabs
    else:
        list_of_tabs = xl.sheet_names
    generate_statements(xl,args.filename,list_of_tabs)
        
    
    
def generate_statements(xl,filename,tabs):
    i = 1
    for tab in tabs:
        print("Generating statements for "+tab+"....")
        df = pd.read_excel(xl, tab)
        sql_texts = []
        for index, row in df.iterrows():
            sql_texts.append('INSERT INTO '+tab+' ('+ str(', '.join(df.columns))+ ') VALUES '+ str(tuple(row.values)) + ";")
        with open(str(i).zfill(2)+"."+tab+".sql", "w", encoding="utf-8") as f:
            for string in sql_texts:
                string = string.replace('nan','NULL')
                f.write(string+"\n")
        i= i + 1
        print("Statements generation done for "+tab+".")


if __name__=="__main__":
    main()